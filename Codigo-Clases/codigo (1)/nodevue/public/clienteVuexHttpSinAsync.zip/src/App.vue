<template>
  <div id="app" class="container-fluid mt-3">
    <div class="jumbotron">
      <!-- <h1>Bienvenidos a Vue.js CLI {{contador}}</h1> -->
      <h1>Bienvenidos a Vue.js CLI {{mostrarContador}}</h1>
      <br>
      <!-- <ContadorVuex @contador="setContador($event)" />
      <Navbar :contador="getContador()" /> -->
      <ContadorVuex />
      <ContadorVuex />
      <Http />
      <Alumnos />

      <Navbar />
      <router-view />
    </div>
  </div>
</template>

<script>
import Navbar from './components/Navbar.vue'
import ContadorVuex from './components/ContadorVuex.vue'
import Http from './components/Http.vue'
import Alumnos from './components/Alumnos.vue'
import miMixinsExt from './miMixins.js'

export default {
  name: 'App',
  mixins : [miMixinsExt],
  components: {
    Navbar,
    ContadorVuex,
    Http,
    Alumnos
  }/* ,
  data() {
    return {
      contador : 0
    }
  },
  methods: {
    setContador(valor) {
      console.log(valor)
      this.contador = valor
    },
    getContador() {
      return this.contador
    }
  } */
}
</script>

<style>
  #app {
  }

  h1 {
    color: blue;
  }

</style>
