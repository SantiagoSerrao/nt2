<template>

  <section class="src-components-http">
    <div class="jumbotron">
      <h2>Alumnos</h2>
      <hr />
        <ul>
            <li v-for="(alumno, index) in mostrarAlumnos" :key="index">
                <h3>{{alumno.nombre}} {{alumno.apellido}}</h3>
            </li>
        </ul>
    </div>
  </section>

</template>

<script>
  import miMixinsExt from '../miMixins.js'

  export default  {
    name: 'src-components-http',
    mixins : [miMixinsExt],
    props: [],
    
    /* ------------------------------------------- */
    data () {
      return {
      }
    },
    methods: {
    },
    computed: {
    }
}


</script>

<style scoped lang="css">
  .jumbotron {
    background-color:rgb(226, 101, 43);
    color: white;
  }

  hr {
    background-color: #ddd;
  }

  pre {
    color: white;
  }

  .src-components-http {

  }
</style>
