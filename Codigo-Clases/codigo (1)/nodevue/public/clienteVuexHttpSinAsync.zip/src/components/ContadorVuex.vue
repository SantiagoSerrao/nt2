<template>

  <section class="src-components-contador-vuex">
    <div class="jumbotron">
      <h2>ContadorVuex</h2>
      <hr />

      <h3>Contador: {{ mostrarContador }}</h3>
      <button class="btn btn-success m-2" @click="decrementar()">Decrementar</button>
      <button class="btn btn-success m-2" @click="incrementar()">Incrementar</button>

    </div>
  </section>

</template>

<script>

  import miMixinsExt from '../miMixins.js'

  export default  {
    name: 'src-components-contador-vuex',
    props: ['onContador'],
    mixins: [miMixinsExt],
    mounted () {

    },
    data () {
      return {
        //contador : 456
      }
    },
    methods: {
        decrementar() {
          //this.contador--
          this.$store.dispatch('contarDown',2)
        },
        incrementar() {
          //this.contador++
          console.log('dispatch -> contarUp',3, Date.now())
          this.$store.dispatch('contarUp',3)
        }
    },
    computed: {
    }
}


</script>

<style scoped lang="css">
  .src-components-contador-vuex {

  }

  .jumbotron {
      background-color: blueviolet;
      color: white;
  }

  hr {
      background-color: #ddd;
  }  
</style>
