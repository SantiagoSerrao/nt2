import { createStore } from 'vuex'

export default createStore({
    state() {
        return {
            contador: 1234,
            alumnos : []
        }
    },
    actions: {
        /* Contador */
        contarUp({commit}, cant) {
            console.log('action -> contarUp',cant, Date.now())
            commit('incrementar',cant)
        },
        contarDown({commit}, cant) {
            commit('decrementar',cant)
        },
        /* Alumnos */
        guardarAlumnos({commit},alumnos) {
            console.log('action -> guardarAlumnos',alumnos, Date.now())
            commit('guardarAlumnos',alumnos)
        },
        incorporarAlumno({commit},alumno) {
            console.log('action -> incorporarAlumno',alumno, Date.now())
            commit('incorporarAlumno',alumno)
        },
        modificarAlumno({commit},{id,alumno}) {
            console.log('action -> modificarAlumno',{id,alumno}, Date.now())
            commit('modificarAlumno',{id,alumno})
        },
        borrarAlumno({commit},id) {
            console.log('action -> borrarAlumno',id, Date.now())
            commit('borrarAlumno',id)
        }
    },
    mutations: {
        /* Contador */
        incrementar(state,cant) {
            console.log('mutation -> incrementar',state, cant, Date.now())
            state.contador += cant
        },
        decrementar(state,cant) {
            state.contador -= cant
        },
        /* Alumnos */
        guardarAlumnos(state,alumnos) {
            console.log('mutation -> guardarAlumnos',state, alumnos, Date.now())
            state.alumnos = alumnos
        },
        incorporarAlumno(state,alumno) {
            console.log('mutation -> incorporarAlumno',state, alumno, Date.now())
            state.alumnos.push(alumno)
        },
        modificarAlumno(state,{id,alumno}) {
            console.log('mutation -> modificarAlumno',state, {id,alumno}, Date.now())
            let offset = state.alumnos.findIndex(alumno => alumno.id == id)
            state.alumnos.splice(offset,1,alumno)
        },
        borrarAlumno(state,id) {
            console.log('mutation -> borrarAlumno',state, id, Date.now())
            let offset = state.alumnos.findIndex(alumno => alumno.id == id)
            state.alumnos.splice(offset,1)
        }
    }
})