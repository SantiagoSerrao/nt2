export default  {
    mounted: function() {
      this.saludo2()
    },
    methods : {
      saludo2 : function() {
        console.log('Hola desde el mixin mounted')
      }
    },
    computed: {
      mostrarContador() {
        //this.$emit('contador', this.contador)
        //return this.contador
        return this.$store.state.contador
      },
      mostrarAlumnos() {
        return this.$store.state.alumnos
      }
    }    
}