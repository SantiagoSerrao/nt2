import { createStore } from 'vuex'
import axios from 'axios'

const url = 'https://5c8ef17a3e557700145e85c7.mockapi.io/alumnos/'

export default createStore({
    state() {
        return {
            contador: 1234,
            alumnos : []
        }
    },
    actions: {
        /* Contador */
        contarUp({commit}, cant) {
            console.log('action -> contarUp',cant, Date.now())
            commit('incrementar',cant)
        },
        contarDown({commit}, cant) {
            commit('decrementar',cant)
        },

        /* Peticiones Asyncrónicas */
        async getAlumnosAxios({commit}) {
            try {
                let res = await axios(url)
                console.log(res.data)
                commit('guardarAlumnos',res.data)
            }
            catch(error) {
                console.log('HTTP GET ERROR', error)
            }
        },
        postAlumnoAxios({commit},alumno) {
            axios.post(url, alumno, {'content-type':'application/json'})
            .then(res => {
                let alumno = res.data
                console.log(alumno)
                commit('incorporarAlumno',alumno)
            })
            .catch(error => console.log('HTTP POST ERROR', error))
        },
        putAlumnoAxios({commit},{id,alumno}) {
            axios.put(url+id, alumno, {'content-type':'application/json'})
            .then(res => {
              let alumno = res.data
              console.log(alumno)
              commit('modificarAlumno',{id,alumno})
            })
            .catch(error => console.log('HTTP PUT ERROR', error))
        },
        deleteAlumnoAxios({commit},id) {
            axios.delete(url+id)
            .then(res => {
              let alumno = res.data
              console.log(alumno)
              commit('borrarAlumno',id)
            })
            .catch(error => console.log('HTTP DELETE ERROR', error))
        }
    },
    mutations: {
        /* Contador */
        incrementar(state,cant) {
            console.log('mutation -> incrementar',state, cant, Date.now())
            state.contador += cant
        },
        decrementar(state,cant) {
            state.contador -= cant
        },
        /* Alumnos */
        guardarAlumnos(state,alumnos) {
            console.log('mutation -> guardarAlumnos',state, alumnos, Date.now())
            state.alumnos = alumnos
        },
        incorporarAlumno(state,alumno) {
            console.log('mutation -> incorporarAlumno',state, alumno, Date.now())
            state.alumnos.push(alumno)
        },
        modificarAlumno(state,{id,alumno}) {
            console.log('mutation -> modificarAlumno',state, {id,alumno}, Date.now())
            let offset = state.alumnos.findIndex(alumno => alumno.id == id)
            state.alumnos.splice(offset,1,alumno)
        },
        borrarAlumno(state,id) {
            console.log('mutation -> borrarAlumno',state, id, Date.now())
            let offset = state.alumnos.findIndex(alumno => alumno.id == id)
            state.alumnos.splice(offset,1)
        }
    }
})