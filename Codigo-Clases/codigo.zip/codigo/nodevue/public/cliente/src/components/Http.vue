<template>

  <section class="src-components-http">
    <div class="jumbotron">
      <h2>Http</h2>
      <hr />

      <!-- <pre>{{alumnos}}</pre> -->

      <button class="btn btn-success mx-3" @click="getAlumnosAxios()">GET</button>
      <button class="btn btn-info mx-3" @click="postAlumnoAxios()">POST</button>

      <div class="media alert alert-info mt-4" v-for="(alumno, index) in mostrarAlumnos" :key="index">
        <img :src="alumno.foto" width="250" :style="{'border-radius':'20px'}" :alt="alumno.nombre">

        <div class="media-body ml-3">
          <h4>Alumno {{index+1}} - ID: {{alumno.id}} - creado: {{formatearFecha(alumno.createdAt)}}</h4>
          <!-- <h4>Alumno {{index+1}} - ID: {{alumno.id}} - creado: {{ alumno.createdAt | formatearFecha}}</h4> -->
          <br>
          <p>Nombre: <b><a :href="alumno.foto">{{alumno.nombre}} {{alumno.apellido}}</a></b></p>
          <p>Edad: <i>{{alumno.edad}}</i></p>
          <p>curso: <i>{{alumno.curso?'Si':'No'}}</i></p>

          <button class="btn btn-warning m-3" @click="putAlumnoAxios(alumno.id)">PUT</button>
          <button class="btn btn-danger m-3" @click="deleteAlumnoAxios(alumno.id)">DELETE</button>

        </div>
      </div>

    </div>
  </section>

</template>

<script>
  import filters from '../filters.js'
  import miMixinsExt from '../miMixins.js'

  export default  {
    name: 'src-components-http',
    mixins : [filters,miMixinsExt],
    props: [],
    data () {
      return {
      }
    },
    methods: {
      /* ------------------------------------ */
      /*         API REST -> GET              */
      /* ------------------------------------ */
      getAlumnosAxios() {
          this.$store.dispatch('getAlumnosAxios')
      },
      /* ------------------------------------ */
      /*         API REST -> POST             */
      /* ------------------------------------ */
      postAlumnoAxios() {
        let alumno = {
          nombre: "Daniel",
          apellido: "Sánchez",
          edad: 51,
          curso: true,
          foto: "https://cdn3.iconfinder.com/data/icons/business-avatar-1/512/12_avatar-256.png"          
        }
        this.$store.dispatch('postAlumnoAxios',alumno)
      },
      /* ------------------------------------ */
      /*         API REST -> PUT              */
      /* ------------------------------------ */
      putAlumnoAxios(id) {
        console.log('put',id)

        let alumno = {
          nombre: "Ana",
          apellido: "Lopez",
          edad: 32,
          curso: false,
          foto: "https://cdn3.iconfinder.com/data/icons/business-avatar-1/512/11_avatar-256.png"
        }
        this.$store.dispatch('putAlumnoAxios',{id,alumno})
      },
      /* ------------------------------------ */
      /*         API REST -> DELETE           */
      /* ------------------------------------ */
      deleteAlumnoAxios(id) {
        console.log('delete',id)
        this.$store.dispatch('deleteAlumnoAxios',id)
      }
    },
    computed: {

    }
}


</script>

<style scoped lang="css">
  .jumbotron {
    background-color:blueviolet;
    color: white;
  }

  hr {
    background-color: #ddd;
  }

  pre {
    color: white;
  }

  .src-components-http {

  }
</style>
