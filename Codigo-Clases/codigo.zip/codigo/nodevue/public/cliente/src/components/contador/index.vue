<template src="./src/components/contador.html"></template>
<script src="./src/components/contador.js"></script>
<style src="./src/components/contador.css" scoped lang="css"></style>

